import React from 'react'

export default function Topbar() {
  return (
    // <!-- Top Bar Start -->

    <ul className="list-inline float-right mb-0">
        {/* <!-- Search --> */}
        {/* <li className="list-inline-item dropdown notification-list">
            <button className="nav-link waves-effect toggle-search" href="javascript:void(0)"  data-target="#search-wrap">
                <i className="mdi mdi-magnify noti-icon"></i>
            </button>
        </li> */}
        {/* <!-- Fullscreen --> */}
        {/* <li className="list-inline-item dropdown notification-list hidden-xs-down">
            <button className="nav-link waves-effect" href="javascript:void(0)" id="btn-fullscreen">
                <i className="mdi mdi-fullscreen noti-icon"></i>
            </button>
        </li> */}
    
        {/* <!-- User--> */}
        {/* <li className="list-inline-item dropdown notification-list">
            <a className="nav-link dropdown-toggle arrow-none waves-effect nav-user" data-toggle="dropdown" href="#" role="button"
                aria-haspopup="false" aria-expanded="false">
                <img src="" alt="user" className="rounded-circle" />
            </a>
            <div className="dropdown-menu dropdown-menu-right profile-dropdown ">
                <a className="dropdown-item" href=""><i className="dripicons-user text-muted"></i> Profile</a>
                
                <div className="dropdown-divider"></div>
                <a className="dropdown-item" href=""><i className="dripicons-exit text-muted"></i> Logout</a>
            </div>
        </li> */}
    </ul>
  )
}
