import React from 'react';

function Empty() {
  return <div><h1>Empty</h1>
  
  </div>;
}

export default Empty;
